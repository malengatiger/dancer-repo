"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Rating {
    constructor() {
        this.driver = '';
        this.overall = '';
        this.rank = '';
        this.vehicle = '';
    }
}
exports.default = Rating;
//# sourceMappingURL=rating.js.map