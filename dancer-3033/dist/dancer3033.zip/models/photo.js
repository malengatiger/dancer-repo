"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Photo {
    constructor() {
        this.created = new Date().toISOString();
    }
}
exports.default = Photo;
//# sourceMappingURL=photo.js.map