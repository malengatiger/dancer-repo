import { CollectionReference, Firestore, Query } from "@google-cloud/firestore";
import * as admin from "firebase-admin";
