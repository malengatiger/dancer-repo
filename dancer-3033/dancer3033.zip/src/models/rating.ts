class Rating {
  public driver: string;
  public overall: string;
  public rank: string;
  public vehicle: string;

  constructor() {
    this.driver = '';
    this.overall = '';
    this.rank = '';
    this.vehicle = '';
  }
}

export default Rating;
